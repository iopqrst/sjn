package com.alibaba.fastjson.serializer;


public interface SerializeFilter {

}
